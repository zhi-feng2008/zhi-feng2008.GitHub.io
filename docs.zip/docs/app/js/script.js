console.log("TemplateServer");
console.log("Website by: github.com/OLIMINATOR");